/*
 * Copyright (c) 2017 Andy Yan
 *
 * SPDX-License-Identifier:     GPL-2.0+
 */
#include <common.h>

int board_init(void)
{
	return 0;
}
