#include "fdt_host.h"
#include "../scripts/dtc/libfdt/fdt.c"
