#include <../common/hash.c>
