#include <../lib/libfdt/fdt_rw.c>
