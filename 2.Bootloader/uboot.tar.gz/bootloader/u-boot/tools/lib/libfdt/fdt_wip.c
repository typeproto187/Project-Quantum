#include <../lib/libfdt/fdt_wip.c>
