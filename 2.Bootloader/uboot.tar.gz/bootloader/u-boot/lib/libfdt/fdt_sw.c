#include <linux/libfdt_env.h>
#include "../../scripts/dtc/libfdt/fdt_sw.c"
