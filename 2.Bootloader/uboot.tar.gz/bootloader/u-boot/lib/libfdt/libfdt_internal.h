#include "../../scripts/dtc/libfdt/libfdt_internal.h"
